monto = float(input("Ingresa el monto de compra: "))

if monto >= 500:
    print("Se aplica el descuento de 20%. \nTotal:",(monto*0.8))
elif monto >= 200:
    print("Se aplica el descuento de 10%. \nTotal:",(monto*0.9))
else:
    print("No se aplica ningun descuento. \nTotal:", monto)
