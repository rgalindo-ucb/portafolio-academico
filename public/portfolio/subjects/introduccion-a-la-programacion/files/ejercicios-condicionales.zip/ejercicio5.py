num = int(input("Ingresa un numero: "))

if num == 0:
    print("El numero ingresado es 0")
elif num > 0 and num % 2 == 0:
    print("El numero es positivo y par")
elif num > 0 and num % 2 != 0:
    print("EL numero es positivo e impar")
else:
    print("El numero es negativo")
