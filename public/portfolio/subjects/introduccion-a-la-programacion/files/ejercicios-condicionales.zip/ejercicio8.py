temp = float(input("Ingresa la temperatura en grados Celsius: "))

if temp < 10:
    print("Hace frío")
elif temp <= 25:
    print("Clima templado")
else:
    print("Hace calor")