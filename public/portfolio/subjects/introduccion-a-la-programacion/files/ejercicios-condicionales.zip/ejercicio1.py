num1 = float(input("Ingrese el primer numero "))
num2 = float(input("Ingrese el segundo numero "))
num3 = float(input("Ingrese el tercer numero "))

if num1 == num2 == num3:
    print("Todos los números son iguales")
else:
    mayor = max(num1,num2,num3)
    print("El mayor es:", mayor)