edad = int(input("Ingresa tu edad: "))

if edad <= 12:
    print("Eres un Niño")
elif edad <= 17:
    print("Eres un Adolecente")
elif edad <= 64:
    print("Eres un Adulto")
else:
    print("Eres un Adulto mayor")