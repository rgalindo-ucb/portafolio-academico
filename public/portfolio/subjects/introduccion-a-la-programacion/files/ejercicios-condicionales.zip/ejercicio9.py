nota = float(input("Ingresa la nota del estudiante: "))
ingreso_fam = float(input("Introduce el ingreso familiar del estudiante: "))


if nota >= 80 or (nota >= 70 and ingreso_fam < 2000):
    print("Obtiene beca")
else:
    print("No obtiene beca")