ingreso = float(input("Introduce tu ingreso mensual "))
antig = int(input("Introduce tus años de trabajo "))

if ingreso >= 4000 or antig > 5:
    print("Préstamos aprobado")
else:
    print("Préstamo rechazado")




