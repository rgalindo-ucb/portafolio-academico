usuario = input("Ingresa tu usuario: ")
contra = input("Ingresa tu contraseña: ")


if usuario == "admin":
    if contra == "python123":
        print("Acceso correcto")
    else:
        print("Contraseña incorrecta")
else:
    print("Usuario incorrecto")