num1 = int(input("Ingresa el primer numero: "))
num2 = int(input("Ingresa el segundo numero: "))

operation = input("Ingresa la operacion a realizar: ")
valid_op = ["+", "-","*","/"]

if operation in valid_op:
    if operation == valid_op[0]:
        print("El resultado es", num1+num2)
    elif operation == valid_op[1]:
        print("El resultado es", num1 - num2)
    elif operation == valid_op[2]:
        print("El resultado es", num1 * num2)
    elif operation == valid_op[3]:
        if num2 == 0:
            print("No se puede dividir entre 0")
        else:
            print("El resultado es", num1 / num2)
else:
    print("Operacion no valida")
