nota = float(input("Ingresa la nota del estudiante "))
asistencia = float(input("Ingresa el porcentaje de asistencia del estudiante "))

if nota >= 51 and asistencia >= 75:
    print("Aprueba la materia")
else:
    print("No aprueba la materia")

    
 