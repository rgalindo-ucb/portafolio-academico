num = int(input("Ingresa un numero: "))
suma_divs = 0
for i in range(1,num+1):
    for j in range(1,i):
        if i % j == 0:
            suma_divs += j
    if suma_divs == i:
        print(f" {i} es un numero especial (percfecto)")
    suma_divs = 0
