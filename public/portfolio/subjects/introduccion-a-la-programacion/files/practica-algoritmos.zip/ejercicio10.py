resutado = 0

while True:
    eleccion = int(input("1. Sumar\n2. Multiplicar\n3.Verificar si el ultimo resultado es mayor a 50\n4.Salir\n"))

    if eleccion == 1:
        a = int(input("Ingresa un numero: "))
        b = int(input("Ingresa un segundo numero: "))
        print(f"La suma de {a} + {b} es igual a {a+b}\n")
        resultado = a + b
    elif eleccion == 2:
        a = int(input("Ingresa un numero: "))
        b = int(input("Ingresa un segundo numero: "))
        print(f"La multiplicacion de {a} * {b} es igual a {a*b}\n")
        resultado = a * b
    elif eleccion == 3:
        if resultado > 50:
            print(f"Si!! El ultimo resultado ({resultado}) es mayor a 50\n")
        else:
            print(f"No. El ultimo resultado ({resultado}) no es mayor a 50\n")
    elif eleccion == 4:
        break
