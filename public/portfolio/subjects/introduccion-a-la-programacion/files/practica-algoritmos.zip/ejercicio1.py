for i in range(1,51):
    if i % 4 == 0 and i % 6 == 0:
        print(i, "muy críticos")
    elif i % 4 == 0:
        print(i, "especiales")
    elif i % 6 == 0:
        print(i, "críticos")
    else:
        print(i)