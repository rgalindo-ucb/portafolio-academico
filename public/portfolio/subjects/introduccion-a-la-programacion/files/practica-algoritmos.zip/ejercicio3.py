num = int(input("Ingresa un numero: "))
cont_divisores = 0
divisores = []
for i in range(1,num+1):
    if num % i == 0:
        divisores.append(i)
        cont_divisores += 1

print(f"Los divisores de {num} son {divisores}")
if cont_divisores > 4:
    print(f"{num} tiene más divisores de lo normal, y son {len(divisores)} divisores")
    
else:
    print(f"{num} tiene {len(divisores)} lo cual es normal")
