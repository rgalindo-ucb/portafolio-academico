num = int(input("Ingresa un numero: "))

for i in range(1,11):
    resultado = num*i
    if resultado % 2 == 0 and resultado % 7 == 0:
        print(f"{num} x {i} = {resultado} MULT7 PAR")
    elif resultado % 2 == 0:
        print(f"{num} x {i} = {resultado} PAR")
    elif resultado % 7 == 0:
        print(f"{num} x {i} = {resultado} MULT7")
    else:
        print(f"{num} x {i} = {resultado}")