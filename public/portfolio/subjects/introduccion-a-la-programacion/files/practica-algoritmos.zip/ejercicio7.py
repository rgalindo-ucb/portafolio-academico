
while True:
    num = int(input("Ingresa un numero valido (entre 10 - 100 y debe ser multiplo de 3): "))
    if (num % 3 == 0) and (10 < num < 100):
        break
print(f"Bien hecho {num} es un numero valido! ")