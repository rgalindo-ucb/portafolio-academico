num = int(input("Ingresa un numero (0 para salir): " ))
    
maximo = num
minimo = num
mayores_veinte = 0
while num != 0:
    if num > 20:
        mayores_veinte += 1

    if num > maximo:
        maximo = num
    elif num < minimo:
        minimo = num

    num = int(input("Ingresa un numero (0 para salir): "))

print(f"El valor más alto ingresado fue {maximo}")
print(f"El valor más bajo ingresado fue {minimo}")
print(f"Ingresaste {mayores_veinte} numeros mayores a 20")