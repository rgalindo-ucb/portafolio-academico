texto = input("Ingresa un texto: ").lower()
vocales = "aeiou"
cont_vocales = 0
cont_letras = 0
cont_espacios = 0

for char in texto:
    if char in vocales:
        cont_vocales += 1
    elif char == " ":
        cont_espacios += 1
cont_letras = len(texto) - cont_espacios


print(f"El texto tiene {cont_letras} letras")
print(f"El texto tiene {cont_espacios} espacios")
print(f"El texto tiene {cont_vocales} vocales")