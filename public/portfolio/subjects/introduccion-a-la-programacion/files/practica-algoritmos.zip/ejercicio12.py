saldo = 5000

while True:
    eleccion = int(input("1. Agregar dinero\n2. Retirar\n3. Consultar saldo\n4.Salir\n"))
    if eleccion == 1:
       cantidad = float(input("Ingresa el monto que quieres depositar o agregar: "))
       saldo += cantidad
       print(f"Deposito exitoso!. Tu nuevo saldo es {saldo}")
    elif eleccion == 2:
        cantidad = float(input("Ingresa el monto que desea retirar: "))
        if cantidad <= saldo:
            saldo -= cantidad
            print(f"Retiro exitoso!. Tu nuevo saldo es {saldo}")
        else:
            print(f"Operacion fallida. No tienes suficiente saldo para ese retiro. Tu saldo actual es de {saldo}")
    elif eleccion == 3:
        print(f"Tu saldo actual es {saldo}")        
    elif eleccion == 4:
        break
