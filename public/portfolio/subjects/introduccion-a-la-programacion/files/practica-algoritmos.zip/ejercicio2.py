aprobados = 0
reprobados = 0
promedio = 0
for i in range(8):
    nota = float(input("Ingrese la nota del estudiante: "))
    if nota > 50:
        aprobados += 1
    else:
        reprobados += 1
    promedio += nota

promedio = promedio / 8
print(f"Hubo {aprobados} estudiantes aprobados")
print(f"Hubo {reprobados} estudiantes reprobados")
print(f"El promedio general del curso fue de: {promedio}")

