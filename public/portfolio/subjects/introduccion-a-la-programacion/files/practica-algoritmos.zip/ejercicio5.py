num = int(input("Ingresa un numero: "))
fact = 1
sum = 0
if num % 2 == 0:
    for i in range(1,num+1):
        fact *= i
    else:
        print(f"El resultado es {fact}")
else:
    for i in range(num+1):
        sum += i
    else:
        print(f"El resultado es {sum}")


