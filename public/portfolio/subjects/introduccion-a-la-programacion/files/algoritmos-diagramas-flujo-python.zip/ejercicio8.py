horas_trabajadas = int(input("Ingrese el total de horas trabajadas: "))
pago_hora = float(input("Ingrese el pago por hora: "))
if horas_trabajadas > 40:
    horas_extra = horas_trabajadas - 40
    monto_total = (40*pago_hora) + (horas_extra*2*pago_hora) 
else:
    monto_total = (horas_trabajadas*pago_hora)
    
print("El monto total a pagar es:", monto_total)