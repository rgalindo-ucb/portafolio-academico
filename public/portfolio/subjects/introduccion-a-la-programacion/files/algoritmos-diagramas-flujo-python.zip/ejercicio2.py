a = float(input("Ingrese la cantidad de bolivianos a convertir:\n"))

monto_dolar = a / 6.96

print(f"{a} bolivianos son ${monto_dolar:.2f} dólares")
