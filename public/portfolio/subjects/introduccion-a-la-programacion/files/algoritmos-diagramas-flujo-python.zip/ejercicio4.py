a = int(input("Ingrese un numero: "))

if a%2==0:
    print("El número es par")
else:
    print("El número es impar")