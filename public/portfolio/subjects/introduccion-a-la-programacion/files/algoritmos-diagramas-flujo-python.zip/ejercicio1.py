a = int(input("Ingrese la base del rectángulo: \n"))
b = int(input("Ingrese la altura del rectángulo: \n"))

area = a*b

print("El área del rectángulo es:", area)
