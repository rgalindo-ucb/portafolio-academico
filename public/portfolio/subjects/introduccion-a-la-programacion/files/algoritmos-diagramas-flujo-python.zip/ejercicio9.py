anno_nacim = int(input("Ingresa el año de nacimiento: "))
anno_actual = int(input("Ingresa el año actual: "))


edad = anno_actual - anno_nacim

print("Tu edad es:", edad)


