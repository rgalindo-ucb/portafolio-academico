a = float(input("Ingrese A: "))
b = float(input("Ingrese B: "))
c = float(input("Ingrese C: "))

if a > b:
    mayor = "A"
    if a > c:
        pass
    else:
        mayor = "C"
else:
    mayor = "B"
    if b > c:
        pass
    else:
        mayor = "C"


print("El número mayor es", mayor)
