contra = input("Ingresa la contraseña: ")

if contra == "admin123":
    print("Acceso permitido")
else:
    print("Acceso denegado")