a = float(input("Ingrese el primer número: \n"))
b = float(input("Ingrese el segundo número: \n"))
c = float(input("Ingrese el tercer número: \n"))
d = float(input("Ingrese el cuarto número: \n"))

prom = (a+b+c+d)/4

print("El promedio es", prom)

