a = float(input("Ingrese el precio del producto: "))
b = int(input("ingrese la cantidad de productos que desea: "))

if b > 5:
    precio_total = (a*b)*0.85
    print("El precio total a pagar:", precio_total)
else:
    precio_total = (a*b)
    print("El precio total es:", precio_total)