a = float(input("Ingrese la calificación: "))

if a >= 51:
    print("Aprueba")
else:
    print("Reprueaba")

    