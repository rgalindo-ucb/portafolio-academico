frase = input("Ingrese una frase: ")

x = frase.lower().count("a")

print(f" La letra aparece: {x} veces")