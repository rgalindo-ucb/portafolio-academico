frase = input("Ingrese una frase: ").lower()

if "python" in frase:
    print("La frase contiene la palabra python")
else:
    print("La frase no contiene la palabra python")