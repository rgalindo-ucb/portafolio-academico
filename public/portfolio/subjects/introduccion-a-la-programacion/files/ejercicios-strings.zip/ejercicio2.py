nombre_completo = input("Ingrese su nombre completo: ")
nombre, apellido = nombre_completo.split(" ")

print(nombre[0] + apellido[0])
