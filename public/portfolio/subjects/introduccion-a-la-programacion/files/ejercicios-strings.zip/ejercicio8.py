palabra = input("Introduce una palabra: ")

print(palabra[:3])
print(palabra[len(palabra)-3:])