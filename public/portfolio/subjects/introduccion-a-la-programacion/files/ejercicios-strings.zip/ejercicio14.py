palabra = input("Ingresa una palabra: ").lower()

if palabra[0] == "a":
    print("La palabra comienza con A")
else:
    print("La palabra no comienza con A")
