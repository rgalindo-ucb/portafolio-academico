frase = input("Ingresa una frase: ").lower()

vocales = "aeiou"
count = 0
for v in vocales:
   count= count + frase.count(v)

print(f"La frase tiene {count} vocales")