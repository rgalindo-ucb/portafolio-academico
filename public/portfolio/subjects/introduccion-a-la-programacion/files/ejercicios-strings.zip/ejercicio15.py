frase = input("Ingresa una palabra: ")

print(frase.replace("malo","bueno"))