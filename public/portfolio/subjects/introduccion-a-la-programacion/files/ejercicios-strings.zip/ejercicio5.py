frase = input("Ingrese una frase: ")

palabras = frase.split(" ")



print(f"Primera palabra: {palabras[0]}")
print(f"Última palabra: {palabras[-1]}")