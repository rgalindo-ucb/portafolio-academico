frase = input("Ingresa una frase: ")

print(frase.strip())