frase = input("Ingrese la frase: ")

no_espacios = frase.replace(" ","")
print(f"Caracteres totales: {len(frase)}")
print(f"Caracteres sin epspacios {len(no_espacios)}")


