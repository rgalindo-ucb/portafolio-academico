nombre = input("Ingresa tu nombre: ")
apellido = input("Ingresa tu apellido: ")
nacimiento = input("Ingresa tu año de nacimiento: ")


print(nombre[0].lower()+apellido.lower()+nacimiento[2::])