num_tarjeta = input("Ingresa tu numero de tarjeta: ")

num= len(num_tarjeta)-4

print(f"{num*'*'}{num_tarjeta[num:]}" )