frase = input("Ingresa una frase: ")

x = frase.lower().count("python")

print(f"python aparece {x} veces")