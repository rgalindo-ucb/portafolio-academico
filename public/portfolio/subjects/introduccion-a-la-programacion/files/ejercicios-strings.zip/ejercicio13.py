nombre_completo = input("Ingresa tu nombre y apellido: ").lower()
separado = nombre_completo.split()
correo = f"{separado[0]}.{separado[1]}@gmail.com"

print(correo)
