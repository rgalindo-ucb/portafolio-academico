frase = input("Ingrese una frase: ").title()

print(frase)