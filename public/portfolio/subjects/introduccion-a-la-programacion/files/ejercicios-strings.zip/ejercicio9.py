frase = input("Ingresa una frase: ")

palabras = frase.split()

cant = len(palabras)

print(f"La frase tiene {cant} palabras")