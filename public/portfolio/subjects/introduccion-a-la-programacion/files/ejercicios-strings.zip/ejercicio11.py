
texto = input("Ingresa un texto: ")

print("MAYÚSUCULAS:", texto.upper())
print("minúsculas",texto.lower())
