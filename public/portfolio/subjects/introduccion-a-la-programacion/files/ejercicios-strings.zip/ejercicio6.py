frase = input("Ingresa una frase: ")

frase = frase.replace("a","*")

print(frase)