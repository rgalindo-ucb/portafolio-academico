correo = input("Ingresa tu correo electronico: ")

usuario, dominio = correo.split("@")

print("Usuario:", usuario)
print("Dominio:", dominio)