km_recorridos = float(input("Ingrese la cantidad de kilómetros recorridos: "))
consumo_km = float(input("Ingrese el consumo de litros por kilómetro: "))

total = km_recorridos * consumo_km

print(f"El total de litros consumidos es: {total:.2f}")
