temp = float(input("Ingrese la temperatura en grados Celcius: "))
temp_fahr = (temp*9/5)+32

print("La temperatura en Fahrenheit es:", temp_fahr)