lado = float(input("Ingrese la longitud del lado del cuadrado "))

perimetro = lado*4

print("El perímetro es:", perimetro)