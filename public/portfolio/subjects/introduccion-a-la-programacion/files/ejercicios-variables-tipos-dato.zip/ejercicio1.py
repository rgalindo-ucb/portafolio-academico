pago_hora = float(input("Ingrese el pago por hora: "))
horas_trabajadas = float(input("Ingrese las horas trabajadas: "))

salario_total = pago_hora*horas_trabajadas

print("El salario semanal es es", salario_total)