cant_metros = float(input("Ingrese la cantidad de metros a convertir: "))

cant_centim = cant_metros*100

print(f"{cant_metros} metros equivale a {cant_centim} centímetros")
