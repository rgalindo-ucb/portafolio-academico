edad_anos = int(input("Ingrese su edad en años: "))

edad_meses = edad_anos*12

print(f"Tienes {edad_meses} meses aproximadamente")
