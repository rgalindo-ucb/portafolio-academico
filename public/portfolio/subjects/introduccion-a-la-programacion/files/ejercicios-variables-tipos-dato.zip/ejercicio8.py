cant_dolar = float(input("Ingrese la cantidad de dolares a convertir: "))

cant_bs = cant_dolar * 6.96

print(f"${cant_dolar} dólares equivale a Bs. {cant_bs:.2f} bolivianos")