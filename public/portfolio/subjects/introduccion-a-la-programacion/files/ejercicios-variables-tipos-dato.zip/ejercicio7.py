precio = float(input("Ingrese el precio del producto: "))
cant = int(input("Ingrese la cantidad a comprar: "))

print(f"El total a pagar es: {(cant*precio)}")

