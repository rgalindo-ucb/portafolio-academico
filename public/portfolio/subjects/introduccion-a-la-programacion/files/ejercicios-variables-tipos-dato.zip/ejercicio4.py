nota1 = float(input("Ingrese la nota 1: "))
nota2 = float(input("Ingrese la nota 2: "))

prom = (nota1 + nota2)/2

print("El promedio es:", prom)


